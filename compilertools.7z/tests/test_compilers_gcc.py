# -*- coding: utf-8 -*-
"""Tests for GNU Compiler Collection"""
# TODO: tests
