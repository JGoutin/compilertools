# -*- coding: utf-8 -*-
"""Tests for Microsoft Visual C++ Compiler"""
# TODO: tests
