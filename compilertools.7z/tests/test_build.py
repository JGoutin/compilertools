# -*- coding: utf-8 -*-
"""Tests for building"""
# TODO: tests
